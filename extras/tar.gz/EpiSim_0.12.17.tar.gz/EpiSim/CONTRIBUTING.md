## Contributing

Please use the issues tracking system (https://www.github.com/statcan/episim/issues) to report a bug or request a feature.