﻿([Français](#sécurité))

# Security

**Do not post any security issues on the public repository!** Security vulnerabilities must be reported by email to `statcan.opensource-logiciellibre.statcan@canada.ca`

______________________

## Sécurité

**Ne publiez aucun problème de sécurité sur le dépôt publique!** Les vulnérabilités de sécurité doivent être signalées par courriel à `statcan.opensource-logiciellibre.statcan@canada.ca`